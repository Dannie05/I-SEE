# DESCRIPTION
This is a bill payment application, built with nextjs and TypeScript stlyed with tailwind and bootstrap

# DATABASE
Mongodb with mongoose
